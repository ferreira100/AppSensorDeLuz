package com.example.aroldojr.lightsensor;

import android.app.Service;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends AppCompatActivity implements SensorEventListener{

    TextView textView;

    TextView tIp;
    TextView tPort;
    EditText eIp;
    EditText ePort;

    SensorManager sensorManager;
    Sensor sensor;

    private static Socket socket;
    private static ServerSocket serverSocket;
    private static InputStreamReader inputStreamReader;
    private static PrintWriter printWriter;

    String menssage="";
    private static String ip = "";
    int port = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.valueLux);

        tIp = (TextView) findViewById(R.id.valueIp);
        tPort = (TextView) findViewById(R.id.valuePort);
        eIp = (EditText)findViewById(R.id.editIp);
        ePort = (EditText)findViewById(R.id.editPort);

        sensorManager = (SensorManager)getSystemService(Service.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

    }

    // --------------------------------------------------------------------//

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if(event.sensor.getType() == Sensor.TYPE_LIGHT){
            textView.setText("" + event.values[0]);

        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    // --------------------------------------------------------------------//

    public void sendMenssage(View view){

        String stringIp = eIp.getText().toString();
        String intPort = ePort.getText().toString();

        ip = stringIp;
        port = (int) Integer.parseInt(intPort);

        tIp.setText(ip);
        tPort.setText(intPort);

        menssage = textView.getText().toString();
        myTask mt = new myTask();
        mt.execute();

    }

    class myTask extends AsyncTask<Void, Void, Void>{

        @Override
        protected Void doInBackground(Void... voids) {

            menssage = textView.getText().toString();
            myTask mt = new myTask();

            try {

                socket = new Socket(ip, port);
                printWriter = new PrintWriter(socket.getOutputStream());
                printWriter.write(menssage);
                printWriter.flush();
                printWriter.close();
                socket.close();

                mt.execute();

            }catch (IOException e){

            }

            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            return null;
        }
    }

    public void alterarDados(View view){



    }

}
